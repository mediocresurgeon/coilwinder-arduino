Updated Code for XC4630
-----------------------

Works with Mega and Uno.

Remove any old libraries, and ensure all libraries from 'Install libraries' folder have been installed.

The Simple test example does not need the libraries to work, the rest do need the libraries to work.

If you are experiencing conflicts, ensure there are no similarly named libraries installed.

SD card sketches may not work with the Mega unless the Mega Soft SPI option is activated.
